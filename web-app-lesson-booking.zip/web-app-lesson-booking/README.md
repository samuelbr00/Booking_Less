# Web-app Lesson Booking

Project that consists on **an online platform for booking lessons**. There is also an administrative part for admin users, where they can manage courses and teacher offered by the service.

The webapp built using the Vue3 JS framwork as client side, and Java servlets as the server one.